'use strict';

// 중복 주입 방지 — 팝업을 다시 열어 executeScript가 재실행돼도 리스너는 1개만
if (!window.__dfCaptureLoaded) {
  window.__dfCaptureLoaded = true;

  const NS = '__df_cap_';
  let mode = 'element';
  let format = 'png';
  let active = false;

  let overlay = null;   // 요소 모드 하이라이트 박스 / 영역 모드 딤 레이어
  let hint = null;      // 안내 배너
  let selBox = null;    // 영역 드래그 사각형
  let dragStart = null;
  let curEl = null;

  function el(tag, cls, css) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (css) n.style.cssText = css;
    return n;
  }

  function makeHint(text) {
    const h = el('div', NS + 'hint');
    h.textContent = text;
    document.documentElement.appendChild(h);
    return h;
  }

  function cleanup() {
    active = false;
    [overlay, hint, selBox].forEach(n => { if (n && n.parentNode) n.parentNode.removeChild(n); });
    overlay = hint = selBox = dragStart = curEl = null;
    document.removeEventListener('mousemove', onMoveEl, true);
    document.removeEventListener('click', onClickEl, true);
    document.removeEventListener('mousedown', onDownRegion, true);
    document.removeEventListener('mousemove', onMoveRegion, true);
    document.removeEventListener('mouseup', onUpRegion, true);
    document.removeEventListener('keydown', onKey, true);
  }

  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); cleanup(); }
  }

  // ── 요소 선택 모드 ──
  function onMoveEl(e) {
    const target = document.elementFromPoint(e.clientX, e.clientY);
    if (!target || target === curEl) return;
    curEl = target;
    const r = target.getBoundingClientRect();
    Object.assign(overlay.style, {
      display: 'block',
      left: r.left + 'px', top: r.top + 'px',
      width: r.width + 'px', height: r.height + 'px'
    });
  }

  function onClickEl(e) {
    if (!curEl) return;
    e.preventDefault(); e.stopPropagation();
    const r = curEl.getBoundingClientRect();
    finish(r);
  }

  // ── 영역 드래그 모드 ──
  function onDownRegion(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    dragStart = { x: e.clientX, y: e.clientY };
    Object.assign(selBox.style, { display: 'block', left: e.clientX + 'px', top: e.clientY + 'px', width: '0px', height: '0px' });
  }
  function onMoveRegion(e) {
    if (!dragStart) return;
    const x = Math.min(e.clientX, dragStart.x), y = Math.min(e.clientY, dragStart.y);
    const w = Math.abs(e.clientX - dragStart.x), h = Math.abs(e.clientY - dragStart.y);
    Object.assign(selBox.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
  }
  function onUpRegion(e) {
    if (!dragStart) return;
    const x = Math.min(e.clientX, dragStart.x), y = Math.min(e.clientY, dragStart.y);
    const w = Math.abs(e.clientX - dragStart.x), h = Math.abs(e.clientY - dragStart.y);
    dragStart = null;
    if (w < 5 || h < 5) { cleanup(); return; }
    finish({ left: x, top: y, width: w, height: h });
  }

  // ── 선택 확정 → 캡처 ──
  function finish(rect) {
    // 뷰포트 안으로 클램프
    const vw = document.documentElement.clientWidth;
    const vh = document.documentElement.clientHeight;
    const left = Math.max(0, rect.left);
    const top = Math.max(0, rect.top);
    const right = Math.min(vw, rect.left + rect.width);
    const bottom = Math.min(vh, rect.top + rect.height);
    const crop = { x: left, y: top, w: right - left, h: bottom - top };
    if (crop.w < 1 || crop.h < 1) { cleanup(); return; }

    // 우리 UI가 캡처에 찍히지 않도록 먼저 제거
    [overlay, hint, selBox].forEach(n => { if (n) n.style.display = 'none'; });

    // 렌더 반영을 2프레임 기다린 뒤 캡처 요청
    requestAnimationFrame(() => requestAnimationFrame(() => {
      chrome.runtime.sendMessage({ type: 'GRAB' }, (resp) => {
        if (!resp || !resp.ok) { alert('캡처에 실패했습니다: ' + ((resp && resp.error) || '알 수 없는 오류')); cleanup(); return; }
        cropAndSave(resp.dataUrl, crop);
      });
    }));
  }

  function cropAndSave(dataUrl, crop) {
    const dpr = window.devicePixelRatio || 1;
    const img = new Image();
    img.onload = () => {
      const sx = Math.round(crop.x * dpr), sy = Math.round(crop.y * dpr);
      const sw = Math.round(crop.w * dpr), sh = Math.round(crop.h * dpr);
      const canvas = document.createElement('canvas');
      canvas.width = sw; canvas.height = sh;
      const ctx = canvas.getContext('2d');
      if (format === 'jpg') { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, sw, sh); }
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      const mime = format === 'jpg' ? 'image/jpeg' : 'image/png';
      const out = canvas.toDataURL(mime, format === 'jpg' ? 0.92 : undefined);
      const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
      const base = (document.title || 'capture').replace(/[\\/:*?"<>|]+/g, '_').trim().slice(0, 40) || 'capture';
      chrome.runtime.sendMessage({ type: 'SAVE', dataUrl: out, filename: `${base}_${ts}.${format}` }, () => cleanup());
    };
    img.onerror = () => { alert('이미지 처리에 실패했습니다.'); cleanup(); };
    img.src = dataUrl;
  }

  function begin(m, f) {
    if (active) cleanup();
    active = true; mode = m; format = f;
    document.addEventListener('keydown', onKey, true);

    if (mode === 'element') {
      overlay = el('div', NS + 'hl', 'display:none');
      document.documentElement.appendChild(overlay);
      hint = makeHint('요소 위에 마우스를 올리고 클릭하세요 · ESC 취소');
      document.addEventListener('mousemove', onMoveEl, true);
      document.addEventListener('click', onClickEl, true);
    } else {
      overlay = el('div', NS + 'dim');
      document.documentElement.appendChild(overlay);
      selBox = el('div', NS + 'sel', 'display:none');
      document.documentElement.appendChild(selBox);
      hint = makeHint('마우스로 영역을 드래그하세요 · ESC 취소');
      document.addEventListener('mousedown', onDownRegion, true);
      document.addEventListener('mousemove', onMoveRegion, true);
      document.addEventListener('mouseup', onUpRegion, true);
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'START_CAPTURE') begin(msg.mode, msg.format);
  });
}

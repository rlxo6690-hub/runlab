'use strict';

// content.js가 요청하는 두 가지 작업:
//  1) GRAB — 현재 보이는 탭을 PNG로 캡처해 dataUrl 반환
//  2) SAVE — 크롭 완료된 dataUrl을 파일로 다운로드
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === 'GRAB') {
    const windowId = sender.tab ? sender.tab.windowId : chrome.windows.WINDOW_ID_CURRENT;
    chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || '캡처 권한이 없습니다.' });
      } else {
        sendResponse({ ok: true, dataUrl });
      }
    });
    return true; // 비동기 응답
  }

  if (msg.type === 'SAVE') {
    chrome.downloads.download({ url: msg.dataUrl, filename: msg.filename, saveAs: false }, () => {
      sendResponse({ ok: !chrome.runtime.lastError });
    });
    return true;
  }
});

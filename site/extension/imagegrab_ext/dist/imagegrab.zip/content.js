'use strict';

// 중복 주입 방지
if (!window.__igLoaded) {
  window.__igLoaded = true;

  const NS = '__ig_';
  let mode = 'region';
  let active = false;
  let overlay = null, hint = null, selBox = null, dragStart = null, curEl = null, panel = null;

  function el(tag, cls, css) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (css) n.style.cssText = css;
    return n;
  }
  function hintEl(t) {
    const h = el('div', NS + 'hint');
    h.textContent = t;
    document.documentElement.appendChild(h);
    return h;
  }

  function teardownSelect() {
    [overlay, hint, selBox].forEach((n) => { if (n && n.parentNode) n.parentNode.removeChild(n); });
    overlay = hint = selBox = dragStart = curEl = null;
    document.removeEventListener('mousemove', onMoveEl, true);
    document.removeEventListener('click', onClickEl, true);
    document.removeEventListener('mousedown', onDown, true);
    document.removeEventListener('mousemove', onMove, true);
    document.removeEventListener('mouseup', onUp, true);
    active = false;
  }
  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); if (panel) closePanel(); else { teardownSelect(); document.removeEventListener('keydown', onKey, true); } }
  }

  // ── 요소 모드 ──
  function onMoveEl(e) {
    const t = document.elementFromPoint(e.clientX, e.clientY);
    if (!t || t === curEl || t === overlay || t === hint) return;
    curEl = t;
    const r = t.getBoundingClientRect();
    Object.assign(overlay.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
  }
  function onClickEl(e) {
    if (!curEl) return;
    e.preventDefault(); e.stopPropagation();
    const root = curEl;
    teardownSelect();
    const imgs = root.tagName === 'IMG' ? [root] : Array.from(root.querySelectorAll('img'));
    showResult(collectItems(imgs));
  }

  // ── 영역 모드 ──
  function onDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    dragStart = { x: e.clientX, y: e.clientY };
    Object.assign(selBox.style, { display: 'block', left: e.clientX + 'px', top: e.clientY + 'px', width: '0px', height: '0px' });
  }
  function onMove(e) {
    if (!dragStart) return;
    const x = Math.min(e.clientX, dragStart.x), y = Math.min(e.clientY, dragStart.y);
    const w = Math.abs(e.clientX - dragStart.x), h = Math.abs(e.clientY - dragStart.y);
    Object.assign(selBox.style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px' });
  }
  function onUp(e) {
    if (!dragStart) return;
    const x = Math.min(e.clientX, dragStart.x), y = Math.min(e.clientY, dragStart.y);
    const w = Math.abs(e.clientX - dragStart.x), h = Math.abs(e.clientY - dragStart.y);
    dragStart = null;
    if (w < 4 || h < 4) { teardownSelect(); document.removeEventListener('keydown', onKey, true); return; }
    const rect = { left: x, top: y, right: x + w, bottom: y + h };
    teardownSelect();
    const imgs = Array.from(document.images).filter((im) => {
      const r = im.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      return !(r.right < rect.left || r.left > rect.right || r.bottom < rect.top || r.top > rect.bottom);
    });
    showResult(collectItems(imgs));
  }

  // ── 이미지 수집: img → {url, filename, w, h} (URL 기준 중복 제거) ──
  function collectItems(imgs) {
    const seen = new Set();
    const items = [];
    for (const im of imgs) {
      let url = im.currentSrc || im.src || '';
      if (!url || seen.has(url)) continue;
      if (url.startsWith('blob:')) {
        url = blobToDataUrl(im);          // blob:은 canvas로 변환 (실패 시 제외)
        if (!url) continue;
      }
      seen.add(im.currentSrc || im.src);
      items.push({
        url,
        filename: fileNameFor(url, items.length + 1),
        w: im.naturalWidth || 0,
        h: im.naturalHeight || 0,
        preview: im.currentSrc || im.src
      });
    }
    return items;
  }
  function blobToDataUrl(im) {
    try {
      const c = document.createElement('canvas');
      c.width = im.naturalWidth; c.height = im.naturalHeight;
      c.getContext('2d').drawImage(im, 0, 0);
      return c.toDataURL('image/png');
    } catch (e) { return null; }
  }
  function fileNameFor(url, idx) {
    if (url.startsWith('data:')) {
      const m = url.match(/^data:image\/(png|jpeg|jpg|gif|webp|svg\+xml|bmp|avif)/);
      const ext = m ? m[1].replace('jpeg', 'jpg').replace('svg+xml', 'svg') : 'png';
      return 'image_' + idx + '.' + ext;
    }
    let base = '';
    try { base = decodeURIComponent(new URL(url, location.href).pathname.split('/').pop() || ''); } catch (e) {}
    base = base.replace(/[\\/:*?"<>|#%&{}$!'@+`=\s]+/g, '_').slice(0, 80);
    if (!base || base === '_') base = 'image_' + idx;
    if (!/\.(png|jpe?g|gif|webp|svg|bmp|avif|ico)$/i.test(base)) base += '.jpg';
    return base;
  }

  // ── 결과 패널 ──
  function showResult(items) {
    if (panel) closePanel();
    panel = el('div', NS + 'panel');

    const head = el('div', NS + 'phead');
    const title = el('div', NS + 'ptitle'); title.textContent = '찾은 이미지';
    const count = el('div', NS + 'pcount');
    head.appendChild(title); head.appendChild(count);
    panel.appendChild(head);

    if (!items.length) {
      const empty = el('div', NS + 'pempty');
      empty.textContent = '이 영역에서 이미지를 찾지 못했습니다. (CSS 배경이미지·캔버스 그림은 이 도구로 저장되지 않습니다)';
      panel.appendChild(empty);
      const row0 = el('div', NS + 'prow');
      const bClose0 = el('button', NS + 'pbtn'); bClose0.textContent = '닫기';
      bClose0.addEventListener('click', closePanel);
      row0.appendChild(bClose0);
      panel.appendChild(row0);
      document.documentElement.appendChild(panel);
      document.addEventListener('keydown', onKey, true);
      return;
    }

    const checked = items.map(() => true);
    function selCount() { return checked.filter(Boolean).length; }

    const grid = el('div', NS + 'pgrid');
    const cells = items.map((it, i) => {
      const cell = el('div', NS + 'pcell ' + NS + 'on');
      const img = el('img', NS + 'pthumb');
      img.src = it.preview; img.alt = '';
      const mark = el('div', NS + 'pmark'); mark.textContent = '✓';
      const dim = el('div', NS + 'pdim');
      dim.textContent = (it.w && it.h) ? it.w + '×' + it.h : '';
      cell.appendChild(img); cell.appendChild(mark); cell.appendChild(dim);
      cell.addEventListener('click', () => {
        checked[i] = !checked[i];
        cell.classList.toggle(NS + 'on', checked[i]);
        render();
      });
      grid.appendChild(cell);
      return cell;
    });
    panel.appendChild(grid);

    const row = el('div', NS + 'prow');
    const bSave = el('button', NS + 'pbtn ' + NS + 'pprimary');
    const bAll = el('button', NS + 'pbtn');
    const bClose = el('button', NS + 'pbtn'); bClose.textContent = '닫기';
    function render() {
      const n = selCount();
      count.textContent = n + '/' + items.length + '개 선택';
      bSave.textContent = '⬇ 저장 (' + n + ')';
      bSave.disabled = n === 0;
      bAll.textContent = n === items.length ? '전체 해제' : '전체 선택';
    }
    render();
    bAll.addEventListener('click', () => {
      const v = selCount() !== items.length;
      items.forEach((_, i) => { checked[i] = v; cells[i].classList.toggle(NS + 'on', v); });
      render();
    });
    bSave.addEventListener('click', () => {
      const sel = items.filter((_, i) => checked[i]).map((it) => ({ url: it.url, filename: it.filename }));
      if (!sel.length) return;
      chrome.runtime.sendMessage({ type: 'IG_DOWNLOAD', items: sel }, () => {
        const o = bSave.textContent;
        bSave.textContent = '✓ 저장 시작됨';
        setTimeout(() => { bSave.textContent = o; }, 1600);
      });
    });
    bClose.addEventListener('click', closePanel);
    row.appendChild(bSave); row.appendChild(bAll); row.appendChild(bClose);
    panel.appendChild(row);

    const foot = el('div', NS + 'pfoot');
    foot.textContent = '저장 위치: 다운로드 폴더 안 imagegrab 폴더 · 썸네일 클릭으로 선택/해제';
    panel.appendChild(foot);

    document.documentElement.appendChild(panel);
    document.addEventListener('keydown', onKey, true);
  }
  function closePanel() {
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
    panel = null;
    document.removeEventListener('keydown', onKey, true);
  }

  function begin(m) {
    if (active) teardownSelect();
    if (panel) closePanel();
    active = true; mode = m;
    document.addEventListener('keydown', onKey, true);
    if (mode === 'element') {
      overlay = el('div', NS + 'hl', 'display:none');
      document.documentElement.appendChild(overlay);
      hint = hintEl('이미지를 저장할 요소에 마우스를 올리고 클릭 · ESC 취소');
      document.addEventListener('mousemove', onMoveEl, true);
      document.addEventListener('click', onClickEl, true);
    } else {
      overlay = el('div', NS + 'dim');
      document.documentElement.appendChild(overlay);
      selBox = el('div', NS + 'sel', 'display:none');
      document.documentElement.appendChild(selBox);
      hint = hintEl('이미지를 저장할 영역을 드래그 · ESC 취소');
      document.addEventListener('mousedown', onDown, true);
      document.addEventListener('mousemove', onMove, true);
      document.addEventListener('mouseup', onUp, true);
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'IG_START') begin(msg.mode);
  });
}

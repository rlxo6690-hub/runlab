'use strict';

// content.js가 보낸 이미지 목록을 다운로드 폴더(imagegrab/)에 저장
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'IG_DOWNLOAD' && Array.isArray(msg.items)) {
    msg.items.forEach((it) => {
      if (!it || !it.url) return;
      chrome.downloads.download(
        { url: it.url, filename: 'imagegrab/' + (it.filename || 'image'), conflictAction: 'uniquify' },
        () => void chrome.runtime.lastError
      );
    });
    sendResponse({ ok: true, count: msg.items.length });
  }
  return false;
});

'use strict';

function showErr(msg) {
  const e = document.getElementById('err');
  e.textContent = msg;
  e.style.display = 'block';
}

async function start(mode) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) { showErr('활성 탭을 찾을 수 없습니다.'); return; }

  const url = tab.url || '';
  if (/^(chrome|edge|about|chrome-extension|https:\/\/chrome\.google\.com\/webstore|https:\/\/chromewebstore\.google\.com)/.test(url)) {
    showErr('이 페이지에서는 사용할 수 없습니다. 일반 웹페이지에서 사용하세요.');
    return;
  }

  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['selector.css'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    await chrome.tabs.sendMessage(tab.id, { type: 'TG_START', mode });
    window.close();
  } catch (e) {
    showErr('이 페이지에서 시작할 수 없습니다. 페이지를 새로고침한 뒤 다시 시도하세요.');
  }
}

document.getElementById('btnRegion').addEventListener('click', () => start('region'));
document.getElementById('btnElement').addEventListener('click', () => start('element'));

// ── 수집함 (담기로 모은 항목 → CSV 한번에 다운로드) ──
const stashCount = document.getElementById('stashCount');
const btnCsv = document.getElementById('btnCsv');
const btnClear = document.getElementById('btnClear');

function renderStash(items) {
  stashCount.textContent = items.length;
  btnCsv.disabled = btnClear.disabled = items.length === 0;
}
function loadStash(cb) {
  chrome.storage.local.get({ tg_items: [] }, (r) => cb(r.tg_items || []));
}
function csvEscape(v) {
  return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
}
function buildCsv(items) {
  const rows = [['번호', '추출시각', '페이지제목', 'URL', '텍스트']];
  items.forEach((it, i) => rows.push([i + 1, it.ts, it.title, it.url, it.text]));
  return '\uFEFF' + rows.map((r) => r.map(csvEscape).join(',')).join('\r\n');
}

btnCsv.addEventListener('click', () => {
  loadStash((items) => {
    if (!items.length) return;
    const blob = new Blob([buildCsv(items)], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.download = 'textgrab_' + ts + '.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  });
});
btnClear.addEventListener('click', () => {
  loadStash((items) => {
    if (!items.length) return;
    if (confirm('담긴 ' + items.length + '개 항목을 모두 비울까요?')) {
      chrome.storage.local.set({ tg_items: [] }, () => renderStash([]));
    }
  });
});

loadStash(renderStash);
